export default function App(): JSX.Element {
  return <h1>Hello world</h1>
}
